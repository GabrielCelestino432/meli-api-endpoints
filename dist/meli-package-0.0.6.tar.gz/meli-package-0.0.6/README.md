### Crie sua aplicação registrada no Meli em : https://developers.mercadolivre.com.br/devcenter/


Assim que colocar os arquivos do pacote na raiz da sua aplicação, crie dentro da pasta um arquivo .env com os seguintes dados:

CLIENT_ID= ## Insira aqui o ID da sua aplicação registrada no Mercado Livre
CLIENT_SECRET= ## Insira aqui a Chave da aplicação criada
REDIRECT_URI= ## Insira aqui a URI de Redirect registrada no Mercado Livre